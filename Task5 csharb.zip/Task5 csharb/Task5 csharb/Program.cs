﻿namespace Task5_csharb
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TestDefensiveCode();
            PrintText("habiba");
            int sum;
            int product;

            SumAndMultipy(5, 3, out sum, out product);

            Console.WriteLine("Sum = " + sum);
            Console.WriteLine("Product = " + product);


            try
            {
                Console.WriteLine("Enter the first number");
                int num1 = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the Second number");
                int num2 = int.Parse(Console.ReadLine());

                int result = num1 / num2;

                Console.WriteLine("result=" + result);


            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("Cannot divide by zero");

            }
            finally
            {
                Console.WriteLine("Operation complete");
                //بنستخدمها فى جميع الحالات سواء العمليه نجحت او فشلتfinally
            }

            int? number = 10;
            int result2 = number ?? 5;

            Console.WriteLine("Default value" + result2);
            Console.WriteLine("HasValue" + number.HasValue);
            if (number.HasValue)
            {
                Console.WriteLine("value:" + number.Value);
            }
            else
            {
                Console.WriteLine(number is null);
            }
            // What exception occurs when trying to access Value on a null Nullable<T>
            //هيدينى invalid operation Expec  tion

            int[] elements = new int[5];
            try
            {
                Console.WriteLine(elements[5]);
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("index is out of range");
            }
            // Why is it necessary to check array bounds before accessing elements?
            //عشان منوصلش للindex الى مش موجووود


            int[,] enums = new int[3, 3];
            for (int i = 0; i < enums.GetLength(0); i++)
            {
                for (int j = 0; j < enums.GetLength(1); j++)
                {
                    Console.Write($"Enter value for [{i},{j}]: ");
                    enums[i, j] = int.Parse(Console.ReadLine());
                }
            }
            for (int i = 0; i < enums.GetLength(0); i++)
            {
                int rowSum = 0;

                for (int j = 0; j < enums.GetLength(1); j++)
                {
                    rowSum += enums[i, j];
                }

                Console.WriteLine("Sum of Row " + i + " = " + rowSum);
            }

            for (int j = 0; j < enums.GetLength(1); j++)
            {
                int columnSum = 0;

                for (int i = 0; i < enums.GetLength(0); i++)
                {
                    columnSum += enums[i, j];
                }

                Console.WriteLine("Sum of Column " + j + " = " + columnSum);
            }

            //Getlength بتجيبلى عدد العناصر الموجوده فى بعد معين
            ////////////////////////////////////////////////
            ///jagged Array
            int[][] numbers = new int[3][];

            // Give each row a different size
            numbers[0] = new int[3];
            numbers[1] = new int[2];
            numbers[2] = new int[4];

            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = 0; j < numbers[i].Length; j++)
                {
                    Console.Write($"Enter value for [{i}][{j}]: ");
                    numbers[i][j] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("Array values");

            for (int i = 0; i < numbers.Length; i++)
            {
                for (int j = 0; j < numbers[i].Length; j++)
                {
                    Console.Write(numbers[i][j] + " ");
                }

                Console.WriteLine();
            }

            //rectangle memory مخصصه لجدول منتظم 
            //jagged row حسب حجمه الميمورى بتخصص لكل 

            Console.WriteLine("Enter your name");
            string? name = Console.ReadLine();
            Console.WriteLine(name!.Length);
            //بتحددلنا ان المتغير ممكن يبقى null
            //وبتساعدنا نكشف الاخطاء قبل تحديد البرنامج



            Console.WriteLine("Boxing  && UN boxing");
            int x = 10;
            object o1 = x;
            Console.WriteLine(o1);

            try
            {
               
                int y = (int)o1;

                Console.WriteLine("After unboxing" + o1);
            }
            catch (InvalidCastException)
            {
                Console.WriteLine("Invalid Cast!");
            }

            try
            {
                string text = (string)o1;
            }
            catch (InvalidCastException)
            {
                Console.WriteLine("Invalid Cast Exception occurred");
            }

            //What is the performance impact of boxing and unboxing in C#?
            //بيبطىو البرنامج شويه فبيقللو الperformance

            int[] numbers2 = null;
            Console.WriteLine(numbers?.Length);

            numbers2 = new int[] { 10, 20, 30 };

            Console.WriteLine(numbers?.Length);
            //?. بيتاكد الاول ان العمليه مش null لو null هيرجع null ومش هيعمل exception


            Console.Write("Enter a day");
            string day = Console.ReadLine();

            int number3 = day switch
            {
                "Monday" => 1,
                "Tuesday" => 2,
                "Wednesday" => 3,
                "Thursday" => 4,
                "Friday" => 5,
                "Saturday" => 6,
                "Sunday" => 7,
                _ => 0
            };

            Console.WriteLine("Day number = " + number3);













        }
        static void SumAndMultipy(int a,int b,out int sum,out int produt)
        {
            sum = a + b;
            produt = a * b;
            //Why must out parameters be initialized inside the method?
            //لأن الـ out parameter لازم ياخد قيمة جوه الـ method قبل ما الـ method تخلص،
            
        }

        static void PrintText(string text, int count = 5)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine(text);
            }
        }




        static void TestDefensiveCode()
        {
            Console.WriteLine("Enter x");
            int.TryParse(Console.ReadLine(),out int x);
            if (x <= 0)
            {
                Console.WriteLine("x must be Postive");
                return;
            }

            Console.WriteLine("Enter y");
            int.TryParse(Console.ReadLine(), out int y);
            if (y <= 1)
            {
                Console.WriteLine("y must be greater than 1");
                return;
            }
            //int.parseحول القيمه دى الى int وانا متوقعه انها رقم
            //int.Tryparse حاول تحول القيمه الى int وقولى نجحت ولالا

           


        }
       



    }
}



